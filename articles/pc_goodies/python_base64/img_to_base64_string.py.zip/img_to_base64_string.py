#!/usr/bin/env python
#Converts all images in current directory, what matches filter into his base64 strings
#If outToOneFile True, when all output will come to one file out.txt
#otherwise, for each image will be created file with name as image + '.txt'

import base64
import os, fnmatch
import re

filter = "*.png"
outToOneFile = True
#outToOneFile = False

def convert_to_base64( img_file_name ):
  return base64.encodestring(open(img_file_name,"rb").read())

def save_to_file( file_name, content, png_file ):
  f = open( file_name, 'a' )
#  Remove from string all new line symbols
  content = re.sub("\n","",content)

  f.write( '\n\n\n'+png_file+'\n\nbackground-image:url(data:image/png;base64,'+content+');' )
  f.close()


def locate(pattern, root=os.curdir):
  '''Locate all files matching supplied filename pattern in and below
  supplied root directory.'''
  for path, dirs, files in os.walk(os.path.abspath(root)):
      for filename in fnmatch.filter(files, pattern):
          yield os.path.join(path, filename)


for png_file in locate(filter):
#  Save into one file all results
  if( outToOneFile ):
    save_to_file('out.txt',convert_to_base64(png_file), png_file)
  else:
#  Save into output file with name as source image file and appned to end .txt
    save_to_file(png_file+'.txt',convert_to_base64(png_file), png_file)
